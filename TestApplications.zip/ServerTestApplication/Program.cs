﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Controller_Core.ViCharController c = new Controller_Core.ViCharController(500);
        }
    }
}
